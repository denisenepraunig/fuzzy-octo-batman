sap.ui.define([
	"sap/ui/core/util/MockServer"
], function(MockServer) {
	"use strict";
		
			var _sAppModulePath = "fiori.md/",
				_sJsonFilesModulePath = _sAppModulePath + "model";
	return {

		init: function () {
			// create
			var oMockServer = new MockServer({
				rootUri: "/myservice/"
			});
			// configure
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: 1000
			});
			
			var sJsonFilesUrl = jQuery.sap.getModulePath(_sJsonFilesModulePath);
			
			// simulate
			var sPath = jQuery.sap.getModulePath("fiori.md.model");
			oMockServer.simulate(sPath + "/metadata.xml", {
				sMockdataBaseUrl: sJsonFilesUrl,
				bGenerateMissingMockData: true}
			);
			// start
			oMockServer.start();
		}
	};

});